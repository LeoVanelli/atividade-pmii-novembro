var alerta = {
    alertIndex: function(){
        alert("Bem vindo a página inicial: Plugin a ser demonstrado: Câmera!");
    },
    alertPage2: function(){
        alert("Bem vindo a segunda página, Plugin a ser demonstrado: Geolocation!");
    },
    alertPage3: function(){
        alert("Bem vindo a última página, Plugin a ser demonstrado: Battery!");
    }
}